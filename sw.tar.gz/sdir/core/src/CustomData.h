/*
* Copyright 2016 Nu-book Inc.
* Copyright 2016 ZXing authors
*/
// SPDX-License-Identifier: Apache-2.0

#pragma once

namespace ZXing {

class CustomData
{
public:
	virtual ~CustomData() = default;

protected:
	CustomData() = default;
};

} // ZXing
